
Hooks.on('diceSoNiceReady', (dice3d) => {
  dice3d.addSystem({ id: "LCD - Madness", name: "LCD - Madness" }, false);

   dice3d.addDicePreset({
     type: "d20",
     labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12",
       "13",
       "14",
       "15",
       "16",
       "17",
       "18",
       "19",
       "20"
     ],
     system: "LCD - Madness",
	 font:"Metal Mania",
	 // colorset:"LCD - Madness colors",
	 fontScale: 1.1,
	 
   },"d20");

   dice3d.addDicePreset({
     type: "d2",
	      labels: [
       "1",
       "2"
     ],
	 // colorset:"LCD - Madness colors",
     system: "LCD - Madness",
	 fontScale: 1.3,
	 font:"Metal Mania",
	 
   });

   dice3d.addDicePreset({
     type: "d4",
	      labels: [
       "1",
       "2",
       "3",
       "4"
     ],
     system: "LCD - Madness",
	 font:"Metal Mania",
	 // colorset:"LCD - Madness colors",
	 fontScale: 1.2,
	 
   },"d4");

   dice3d.addDicePreset({
     type: "d6",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6"
     ],
     system: "LCD - Madness",
	 font:"Metal Mania",
	 // colorset:"LCD - Madness colors",
	 fontScale: 1.6,
	 
   },"d6");
   
      dice3d.addDicePreset({
     type: "df",
	      labels: [
       "+",
       "",
       "-"
     ],
     system: "LCD - Madness",
	 font:"Metal Mania",
	 // colorset:"LCD - Madness colors",
	 fontScale: 1.8,
	 
   },"df");
   
   dice3d.addDicePreset({
     type: "d8",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8"
     ],
     system: "LCD - Madness",
	 font:"Metal Mania",
	 // colorset:"LCD - Madness colors",
	 fontScale: 1.1,
	 
   },"d8");
   
   dice3d.addDicePreset({
     type: "d10",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10"
     ],
     system: "LCD - Madness",
	 font:"Metal Mania",
	 // colorset:"LCD - Madness colors",
	 fontScale: 1.1,
	 
   },"d10");

   dice3d.addDicePreset({
     type: "d12",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12"
     ],
     system: "LCD - Madness",
	 font:"Metal Mania",
	 // colorset:"LCD - Madness colors",
	 fontScale: 1.3,
	 
   },"d12");
   
   dice3d.addDicePreset({
     type: "d100",
	      labels: [
       "10",
       "20",
       "30",
       "40",
       "50",
       "60",
       "70",
       "80",
       "90",
       "00",
     ],
     system: "LCD - Madness",
	 font:"Metal Mania",
	 // colorset:"LCD - Madness colors",
	 fontScale: 1.0,
	 
   },"d10");
   
   
  dice3d.addTexture("mindbreak", {
    name: "Dark Ooze",
    composite: "multiply",
    source: "modules/lordudice/graphics/dice/madness.png",
	bump: "modules/lordudice/graphics/dice/madness-bump.png"
  })
    .then(() => {
      dice3d.addColorset({
        name: 'LCD - Madness colors',
        description: "Liquid Horrors",
        category: "LCD - Madness",
        background: "#330033",
		foreground: '#adacd5',
		outline: '#cc0099',
        edge: '#4d004d',
		texture: 'mindbreak',
		material: 'metal',
		font:"Metal Mania"
      },"no");
    });

});