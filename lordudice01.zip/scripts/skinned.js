
Hooks.on('diceSoNiceReady', (dice3d) => {
  dice3d.addSystem({ id: "LCD - Forbidden Scrolls", name: "LCD - Forbidden Scrolls" }, false);

   dice3d.addDicePreset({
     type: "d20",
     labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12",
       "13",
       "14",
       "15",
       "16",
       "17",
       "18",
       "19",
       "20"
     ],
     system: "LCD - Forbidden Scrolls",
	 font:"Jim Nightshade",
	 // colorset:"LCD - Forbidden Scrolls colors",
	 fontScale: 1.3,
	 
   },"d20");

   dice3d.addDicePreset({
     type: "d2",
	      labels: [
       "1",
       "2"
     ],
	 // colorset:"LCD - Forbidden Scrolls colors",
     system: "LCD - Forbidden Scrolls",
	 fontScale: 1.3,
	 font:"Jim Nightshade",
	 
   });

   dice3d.addDicePreset({
     type: "d4",
	      labels: [
       "1",
       "2",
       "3",
       "4"
     ],
     system: "LCD - Forbidden Scrolls",
	 font:"Jim Nightshade",
	 // colorset:"LCD - Forbidden Scrolls colors",
	 fontScale: 1.7,
	 
   },"d4");

   dice3d.addDicePreset({
     type: "d6",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6"
     ],
     system: "LCD - Forbidden Scrolls",
	 font:"Jim Nightshade",
	 // colorset:"LCD - Forbidden Scrolls colors",
	 fontScale: 1.8,
	 
   },"d6");
   
      dice3d.addDicePreset({
     type: "df",
	      labels: [
       "+",
       "",
       "-"
     ],
     system: "LCD - Forbidden Scrolls",
	 font:"Jim Nightshade",
	 // colorset:"LCD - Forbidden Scrolls colors",
	 fontScale: 2.9,
	 
   },"df");
   
   dice3d.addDicePreset({
     type: "d8",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8"
     ],
     system: "LCD - Forbidden Scrolls",
	 font:"Jim Nightshade",
	 // colorset:"LCD - Forbidden Scrolls colors",
	 fontScale: 1.3,
	 
   },"d8");
   
   dice3d.addDicePreset({
     type: "d10",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10"
     ],
     system: "LCD - Forbidden Scrolls",
	 font:"Jim Nightshade",
	 // colorset:"LCD - Forbidden Scrolls colors",
	 fontScale: 1.3,
	 
   },"d10");

   dice3d.addDicePreset({
     type: "d12",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12"
     ],
     system: "LCD - Forbidden Scrolls",
	 font:"Jim Nightshade",
	 // colorset:"LCD - Forbidden Scrolls colors",
	 fontScale: 1.3,
	 
   },"d12");
   
   dice3d.addDicePreset({
     type: "d100",
	      labels: [
       "10",
       "20",
       "30",
       "40",
       "50",
       "60",
       "70",
       "80",
       "90",
       "00",
     ],
     system: "LCD - Forbidden Scrolls",
	 font:"Jim Nightshade",
	 // colorset:"LCD - Forbidden Scrolls colors",
	 fontScale: 1.0,
	 
   },"d10");
   
   
  dice3d.addTexture("skincraft", {
    name: "Vile Vellum",
    composite: "darken",
    source: "modules/lordudice/graphics/dice/skin.png",
	bump: "modules/lordudice/graphics/dice/skin-bump.png"
  })
    .then(() => {
      dice3d.addColorset({
        name: 'LCD - Sinister Crafts colors',
        description: "Dark Words",
        category: "LCD - Forbidden Scrolls",
        background: "#3b3c50",
		foreground: '#949494',
		outline: '#260000',
        edge: '#1a1b24',
		texture: 'skincraft',
		material: 'metal'
      },"no");
    });

});