
Hooks.on('diceSoNiceReady', (dice3d) => {
  dice3d.addSystem({ id: "LCD - Writhing Vines", name: "LCD - Writhing Vines" }, false);

   dice3d.addDicePreset({
     type: "d20",
     labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12",
       "13",
       "14",
       "15",
       "16",
       "17",
       "18",
       "19",
       "20"
     ],
     system: "LCD - Writhing Vines",
	 font:"Eater",
	 // colorset:"LCD - Writhing Vines colors",
	 fontScale: 1.1,
	 
   },"d20");

   dice3d.addDicePreset({
     type: "d2",
	      labels: [
       "1",
       "2"
     ],
	 // colorset:"LCD - Writhing Vines colors",
     system: "LCD - Writhing Vines",
	 fontScale: 1.3,
	 font:"Eater",
	 
   });

   dice3d.addDicePreset({
     type: "d4",
	      labels: [
       "1",
       "2",
       "3",
       "4"
     ],
     system: "LCD - Writhing Vines",
	 font:"Eater",
	 // colorset:"LCD - Writhing Vines colors",
	 fontScale: 1.2,
	 
   },"d4");

   dice3d.addDicePreset({
     type: "d6",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6"
     ],
     system: "LCD - Writhing Vines",
	 font:"Eater",
	 // colorset:"LCD - Writhing Vines colors",
	 fontScale: 1.6,
	 
   },"d6");
   
      dice3d.addDicePreset({
     type: "df",
	      labels: [
       "+",
       "",
       "-"
     ],
     system: "LCD - Writhing Vines",
	 font:"Eater",
	 // colorset:"LCD - Writhing Vines colors",
	 fontScale: 2.2,
	 
   },"df");
   
   dice3d.addDicePreset({
     type: "d8",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8"
     ],
     system: "LCD - Writhing Vines",
	 font:"Eater",
	 // colorset:"LCD - Writhing Vines colors",
	 fontScale: 1.1,
	 
   },"d8");
   
   dice3d.addDicePreset({
     type: "d10",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10"
     ],
     system: "LCD - Writhing Vines",
	 font:"Eater",
	 // colorset:"LCD - Writhing Vines colors",
	 fontScale: 1.1,
	 
   },"d10");

   dice3d.addDicePreset({
     type: "d12",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12"
     ],
     system: "LCD - Writhing Vines",
	 font:"Eater",
	 // colorset:"LCD - Writhing Vines colors",
	 fontScale: 1.3,
	 
   },"d12");
   
   dice3d.addDicePreset({
     type: "d100",
	      labels: [
       "10",
       "20",
       "30",
       "40",
       "50",
       "60",
       "70",
       "80",
       "90",
       "00",
     ],
     system: "LCD - Writhing Vines",
	 font:"Eater",
	 // colorset:"LCD - Writhing Vines colors",
	 fontScale: 0.8,
	 
   },"d10");
   
   
  dice3d.addTexture("vines", {
    name: "Writhing Vines",
    composite: "overlay",
    source: "modules/lordudice/graphics/dice/vines.png",
	bump: "modules/lordudice/graphics/dice/vines.png"
  })
    .then(() => {
      dice3d.addColorset({
        name: 'LCD - Writhing Vines colors',
        description: "Unnatural Growth",
        category: "LCD - Writhing Vines",
        background: "#1e3000",
		foreground: '#c9b8ad',
		outline: '#666600',
        edge: '#0e1600',
		texture: 'vines',
		material: 'plastic'
      },"no");
    });

});