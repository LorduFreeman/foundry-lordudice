
Hooks.on('diceSoNiceReady', (dice3d) => {
  dice3d.addSystem({ id: "LCD - Ancient Tombs", name: "LCD - Ancient Tombs" }, false);

   dice3d.addDicePreset({
     type: "d20",
     labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12",
       "13",
       "14",
       "15",
       "16",
       "17",
       "18",
       "19",
       "20"
     ],
	  bumpMaps: ['modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png','modules/lordudice/graphics/dice/pyramidwall-bump.png'],
     system: "LCD - Ancient Tombs",
	 font:"IM Fell English",
	 // colorset:"LCD - Ancient Tombs colors",
	 fontScale: 1.1,
	 
   },"d20");

   dice3d.addDicePreset({
     type: "d2",
	      labels: [
       "☥",
       "🕱"
     ],
	 // colorset:"LCD - Ancient Tombs colors",
     system: "LCD - Ancient Tombs",
	 fontScale: 1.3,
	 font:"IM Fell English",
	 
   });

   dice3d.addDicePreset({
     type: "d4",
	      labels: [
       "1",
       "2",
       "3",
       "4"
     ],
     system: "LCD - Ancient Tombs",
	 font:"IM Fell English",
	 // colorset:"LCD - Ancient Tombs colors",
	 fontScale: 1.2,
	 
   },"d4");

   dice3d.addDicePreset({
     type: "d6",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6"
     ],
     system: "LCD - Ancient Tombs",
	 font:"IM Fell English",
	 // colorset:"LCD - Ancient Tombs colors",
	 fontScale: 1.4,
	 
   },"d6");
   
      dice3d.addDicePreset({
     type: "df",
	      labels: [
       "🕱",
       "",
       "☥"
     ],
     system: "LCD - Ancient Tombs",
	 font:"IM Fell English",
	 // colorset:"LCD - Ancient Tombs colors",
	 fontScale: 1.4,
	 
   },"df");
   
   dice3d.addDicePreset({
     type: "d8",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8"
     ],
     system: "LCD - Ancient Tombs",
	 font:"IM Fell English",
	 // colorset:"LCD - Ancient Tombs colors",
	 fontScale: 1.1,
	 
   },"d8");
   
   dice3d.addDicePreset({
     type: "d10",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10"
     ],
     system: "LCD - Ancient Tombs",
	 font:"IM Fell English",
	 // colorset:"LCD - Ancient Tombs colors",
	 fontScale: 1.1,
	 
   },"d10");

   dice3d.addDicePreset({
     type: "d12",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12"
     ],
     system: "LCD - Ancient Tombs",
	 font:"IM Fell English",
	 // colorset:"LCD - Ancient Tombs colors",
	 fontScale: 1.3,
	 
   },"d12");
   
   dice3d.addDicePreset({
     type: "d100",
	      labels: [
       "10",
       "20",
       "30",
       "40",
       "50",
       "60",
       "70",
       "80",
       "90",
       "00",
     ],
     system: "LCD - Ancient Tombs",
	 font:"IM Fell English",
	 // colorset:"LCD - Ancient Tombs colors",
	 fontScale: 1.0,
	 
   },"d10");
   
   
  dice3d.addTexture("pyramidwall", {
    name: "Desert Walls",
    composite: "multiply",
    source: "modules/lordudice/graphics/dice/pyramidwall.png",
	bump: "modules/lordudice/graphics/dice/pyramidwall-bump.png"
  })
    .then(() => {
      dice3d.addColorset({
        name: 'LCD - Ancient Tombs colors',
        description: "Ancient Walls",
        category: "LCD - Ancient Tombs",
        background: "#b07248",
		foreground: '#2f150c',
		outline: '#432020',
        edge: '#453629',
		texture: 'pyramidwall',
		material: 'metal'
      },"no");
    });

});