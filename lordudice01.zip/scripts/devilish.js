
Hooks.on('diceSoNiceReady', (dice3d) => {
  dice3d.addSystem({ id: "LCD - Path to Ruin", name: "LCD - Path to Ruin" }, false);

   dice3d.addDicePreset({
     type: "d20",
     labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12",
       "13",
       "14",
       "15",
       "16",
       "17",
       "18",
       "19",
       "20"
     ],
     system: "LCD - Path to Ruin",
	 font:"Amarante",
	 // colorset:"LCD - Path to Ruin colors",
	 fontScale: 1.1,
	 
   },"d20");

   dice3d.addDicePreset({
     type: "d2",
	      labels: [
       "1",
       "2"
     ],
	 // colorset:"LCD - Path to Ruin colors",
     system: "LCD - Path to Ruin",
	 fontScale: 1.3,
	 font:"Amarante",
	 
   });

   dice3d.addDicePreset({
     type: "d4",
	      labels: [
       "1",
       "2",
       "3",
       "4"
     ],
     system: "LCD - Path to Ruin",
	 font:"Amarante",
	 // colorset:"LCD - Path to Ruin colors",
	 fontScale: 1.2,
	 
   },"d4");

   dice3d.addDicePreset({
     type: "d6",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6"
     ],
     system: "LCD - Path to Ruin",
	 font:"Amarante",
	 // colorset:"LCD - Path to Ruin colors",
	 fontScale: 1.6,
	 
   },"d6");
   
      dice3d.addDicePreset({
     type: "df",
	      labels: [
       "+",
       "",
       "-"
     ],
     system: "LCD - Path to Ruin",
	 font:"Amarante",
	 // colorset:"LCD - Path to Ruin colors",
	 fontScale: 2.2,
	 
   },"df");
   
   dice3d.addDicePreset({
     type: "d8",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8"
     ],
     system: "LCD - Path to Ruin",
	 font:"Amarante",
	 // colorset:"LCD - Path to Ruin colors",
	 fontScale: 1.1,
	 
   },"d8");
   
   dice3d.addDicePreset({
     type: "d10",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10"
     ],
     system: "LCD - Path to Ruin",
	 font:"Amarante",
	 // colorset:"LCD - Path to Ruin colors",
	 fontScale: 1.1,
	 
   },"d10");

   dice3d.addDicePreset({
     type: "d12",
	      labels: [
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12"
     ],
     system: "LCD - Path to Ruin",
	 font:"Amarante",
	 // colorset:"LCD - Path to Ruin colors",
	 fontScale: 1.3,
	 
   },"d12");
   
   dice3d.addDicePreset({
     type: "d100",
	      labels: [
       "10",
       "20",
       "30",
       "40",
       "50",
       "60",
       "70",
       "80",
       "90",
       "00",
     ],
     system: "LCD - Path to Ruin",
	 font:"Amarante",
	 // colorset:"LCD - Path to Ruin colors",
	 fontScale: 0.8,
	 
   },"d10");
   
   
  dice3d.addTexture("brimstone", {
    name: "Brimstone",
    composite: "multiply",
    source: "modules/lordudice/graphics/dice/brimstone.png",
	bump: "modules/lordudice/graphics/dice/brimstone-bump.png"
  })
    .then(() => {
      dice3d.addColorset({
        name: 'LCD - Path to Ruin colors',
        description: "Old Brimstone",
        category: "LCD - Path to Ruin",
        background: "#ff5c26",
		foreground: '#e1b3ac',
		outline: '#ff8000',
        edge: '#5a0000',
		texture: 'brimstone',
		material: 'metal'
      },"no");
    });

});